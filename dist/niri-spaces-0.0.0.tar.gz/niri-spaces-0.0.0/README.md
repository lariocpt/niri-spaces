# niri-spaces

Declarative workspace layouts for [niri](https://github.com/YaLTeR/niri).

One plain-text file says which apps open on which workspace. `niri-spaces load`
reads it, launches each app, waits for its window, moves it onto the right
workspace and sizes the column — then steps aside. No daemon, nothing running in
the background, and every move it makes is a `niri msg` call you could type
yourself.

<!-- BEGIN GENERATED SHOWCASE (tools/gen-showcase.py) -->
```text
┌────────────────────────────────────────────────────┐
│                 ▐   ▐ ▐▀▀▀  ▐▀▀▄                   │
│                 ▐   ▐ ▐▀▀   ▐▄▄▀                   │
│                 ▐ █ ▐ ▐     ▐   █                  │
│                  ▀ ▀  ▐▄▄▄  ▐▄▄▀                   │
├────────────────────────────────────────────────────┤
│ Workspace: web                                     │
│ Path:      ~/dev/projects/web                      │
│ Branch:    main                                    │
│ Commit:    declarative layouts (2 hours ago)       │
│ Status:    0 modified files                        │
└────────────────────────────────────────────────────┘
```
<!-- END GENERATED SHOWCASE -->

That box is `space-splash` — the real program's output for a `web` workspace,
spliced in by `tools/gen-showcase.py` so it cannot drift from what the code
prints. It shows the folder, its git branch and its latest commit.

## Install

One command:

```sh
curl -fsSL https://lariocpt.github.io/niri-spaces/install.sh | sh
```

It takes the repository's **latest** release. To install a specific one instead:

```sh
curl -fsSL https://lariocpt.github.io/niri-spaces/install.sh | sh -s -- --tag=v0.1.0
```

To see exactly what it would do, and do nothing:

```sh
curl -fsSL https://lariocpt.github.io/niri-spaces/install.sh | sh -s -- --dry-run
```

The archive is fetched and checked against its SHA-256 **before** anything is
installed — it refuses to run an artifact it cannot verify. Then it puts
`niri-spaces` and `space-splash` in `~/.local/bin` and copies the example spaces
and an `autostart` file into `~/.config/niri-spaces/`. Config files are copied
only where they don't already exist, so a file you edited is kept.

**It does not edit your niri config.** It prints the keybind line to add and
leaves the decision to you.

`--prefix=DIR` sets the install root — the bins land in `DIR/bin` — `-h` shows all the
options, and `NIRI_SPACES_REPO` points it at a fork.

## Then wire it up in niri

Two lines, in `~/.config/niri/config.kdl` (or `~/.config/niri/cfg/keybinds.kdl`
if your config uses the `cfg/` split). These are the lines the installer prints
for you — it prints them rather than writing them, because your config is yours.

Have niri's autostart run:

```
niri-spaces start
```

and bind the picker to a key:

```kdl
Mod+Ctrl+Shift+S hotkey-overlay-title="Niri Spaces: Menu" { spawn "niri-spaces" "menu"; }
```

Reload niri and load your first layout:

```sh
niri-spaces load default
```

`menu` opens a picker — `fuzzel` when it's installed and you're on a Wayland
session, otherwise a plain terminal `select` prompt.

## Commands

```
niri-spaces load <name> [args...]   load spaces/<name>.space (or templates/<name>.space with $1..$9 substituted)
niri-spaces start                   run every `load ...` line in ~/.config/niri-spaces/autostart
niri-spaces menu                    pick a space interactively (fuzzel if available, else terminal)
niri-spaces list                    list available spaces and templates
```

Four subcommands, and that is the whole surface. `start` runs each `load` line in
`autostart` in order and finishes by focusing workspace 1.

## The `.space` format

A file is read top to bottom. A `@workspace` line sets the current workspace, and
every app line after it lands there:

| Line | Meaning |
|---|---|
| `@workspace <name-or-index>` | Following app lines target this workspace — a name or a number. |
| `app_id \| command \| env \| capture` | Launch `command`, then find the window whose app id matches `app_id` and move it to the current workspace. `env` is exported for the launch; `capture` names a variable that receives the window id. Both are optional. |
| `@action <shell>` | Run a shell command, e.g. to focus a captured window and size its column. |
| `# …` | Comment. Blank lines are ignored. |

Fields are split on `|`, so a launch command can't contain a literal pipe — no
inline `||` fallbacks. Use `$TERMINAL` / `$BROWSER` instead.

`spaces/default.space`, the fallback the installer ships, verbatim except the
comments:

```
@workspace default
$TERMINAL_APPID | $TERMINAL | | terminal_id
$BROWSER_APPID  | $BROWSER  | | browser_id
@action [ -n "${terminal_id:-}" ] && niri msg action focus-window --id "$terminal_id" && niri msg action set-column-width "50%"
@action [ -n "${browser_id:-}" ] && niri msg action focus-window --id "$browser_id" && niri msg action set-column-width "50%"
```

Run it with `niri-spaces load default`. The shipped `autostart` loads `main` and
`web` instead: `web` is the terminal-and-browser pair on workspace 2, and `main`
is workspace 1 with a `zenith` system monitor in the left column — so `main`
needs `zenith` installed to be worth loading.

### Templates

`templates/<name>.space` may use `$1` … `$9`, substituted from `load`'s
arguments, so one file can describe a family of workspaces:

```sh
niri-spaces load service 3 api
```

### One file, many machines

Spaces name `$TERMINAL` / `$BROWSER` rather than a specific app. At load time the
first installed candidate wins — `ghostty`, `foot`, `alacritty`, `kitty` for the
terminal, and `brave-origin`, `brave`, `firefox`, `google-chrome`, `chromium` for
the browser — and the matching app id is derived for you (`$TERMINAL_APPID`,
`$BROWSER_APPID`). Window matching is a prefix match, so `brave` also covers
`brave-browser-nightly`. Export the variables yourself and your choice wins.

## `space-splash`

A Python 3 script that prints the box at the top of this file: directory, git
branch, last commit, working-tree status. Point your terminal's start hook at it
and each terminal tells you where it is.

## Requirements

- **niri**, running. niri-spaces drives the compositor only through `niri msg`,
  so it needs a live niri session on Wayland. It is a niri tool — it does not
  manage X11 or other compositors.
- **bash** and **jq**. `jq` is not optional: the launcher diffs
  `niri msg --json windows` before and after each spawn to learn the new window's
  id, and without `jq` that diff silently yields nothing — every app then waits
  out the 10-second "no window appeared" timeout and it looks like a slow
  compositor instead of a missing dependency.
- **Python 3** for `space-splash`. Standard library only, no pip installs.

**What it is not:** it is not a session manager. It launches the apps a space
names and puts them where the file says. It does not restore windows you closed.

## Development

```sh
bats tests/                              # the test suite
python3 tools/gen-showcase.py            # re-splice the real splash into README + page
python3 tools/check-site.py              # the docs honesty gate CI runs
shellcheck -s sh docs/install.sh         # installer, in its real shebang's dialect
```

Run the installer against a local build without touching your system:

```sh
docs/install.sh --tag=v0.1.0 --dry-run
```

The test suite is [bats-core](https://github.com/bats-core/bats-core).
`tests/13_shells.bats` runs the installer end to end under bash, dash and busybox
ash, because `#!/bin/sh` is only as strict as whatever it happens to run under.

## Changelog

See [CHANGELOG.md](CHANGELOG.md).

## License

MIT — see [LICENSE](LICENSE).
